# layerly-creatives

Design social creatives, ads and posters in chat and get a **layered .psd** (editable text,
folders, drop-shadow layer styles) plus a PNG preview. No Photoshop required to build it;
opens in Photoshop, Photopea (free, browser), GIMP, Affinity, Krita.

## Install

**Claude (claude.ai / desktop):** Customize > Skills > upload `layerly-creatives.skill` (or the .zip) > toggle on.
Needs "Code execution and file creation" enabled in Settings > Capabilities.

**Claude Code:** copy this folder to `~/.claude/skills/layerly-creatives/`.

**ChatGPT desktop app / Codex:** copy this folder to `~/.agents/skills/layerly-creatives/`
(or `$skill-installer` with the folder path). Codex runs `build_psd.js` (Node) for editable text.

**ChatGPT in the browser:** create a Project, paste `SKILL.md` into Instructions and upload
`scripts/render_layers.py`, `scripts/build_psd.py` and the `assets/fonts` files to the project.
ChatGPT's Python sandbox has no Node, so it uses the Python fallback (text on separate layers,
but rasterized).

## Use

Ask for a design and mention the format, e.g.
"Make an Instagram portrait ad for our citrus drink: headline TASTE THE SUN, CTA Shop now,
brand colors #0E2A26 and #F2C94C, use the product photo I uploaded. Give me the PSD."

## What's inside

- `SKILL.md` — the workflow the AI follows
- `scripts/render_layers.py` — layout.json → per-layer PNGs + preview (Pillow only)
- `scripts/build_psd.py` — pure-Python fallback PSD writer
- `scripts/gen_image.py` — optional: generate images via Gemini/OpenAI API key (terminal only)
- `references/layout-schema.md` — every layout option + design rules
- `assets/fonts/` — Poppins (Bold/Medium/Regular) and Noto Sans Bengali (Bold/Regular), OFL licensed
- `assets/example/` — a complete sample layout + product image

## Try it locally

```bash
python3 scripts/render_layers.py assets/example/layout.json /tmp/build
node scripts/build_psd.js /tmp/build/layers.json /tmp/example.psd
```
