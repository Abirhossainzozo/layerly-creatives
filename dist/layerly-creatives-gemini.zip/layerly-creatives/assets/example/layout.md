# layout.json — copy the block below into a file named layout.json

```json
{
  "name": "citrus-summer-sale",
  "preset": "ig-portrait",
  "background": { "type": "gradient", "from": "#0E2A26", "to": "#1F6B5A", "angle": 60 },
  "layers": [
    { "type": "ellipse", "name": "Glow", "x": 190, "y": 330, "width": 700, "height": 700, "color": "#F2C94C", "opacity": 0.35, "blend": "screen" },
    { "type": "image", "name": "Product", "src": "product.png", "fit": "contain", "x": 240, "y": 300, "width": 600, "height": 640, "group": "Product",
      "shadow": { "color": "#000000", "opacity": 0.55, "distance": 24, "angle": 120, "blur": 40 } },
    { "type": "text", "name": "Eyebrow", "text": "LIMITED SUMMER DROP", "x": 90, "y": 110, "width": 900, "font": "Poppins-Medium", "size": 34, "color": "#F2C94C", "align": "left", "tracking": 200, "group": "Text" },
    { "type": "text", "name": "Headline", "text": "TASTE THE SUN", "x": 90, "y": 160, "width": 900, "font": "Poppins-Bold", "size": 132, "color": "#FFFFFF", "align": "left", "lineHeight": 0.95, "tracking": -20, "group": "Text",
      "shadow": { "color": "#000000", "opacity": 0.4, "distance": 10, "angle": 120, "blur": 24 } },
    { "type": "rect", "name": "CTA button", "x": 90, "y": 1150, "width": 400, "height": 104, "color": "#F2C94C", "radius": 52, "group": "CTA" },
    { "type": "text", "name": "CTA text", "text": "SHOP NOW", "x": 90, "y": 1179, "width": 400, "font": "Poppins-Bold", "size": 36, "color": "#0E2A26", "align": "center", "tracking": 60, "group": "CTA" },
    { "type": "text", "name": "Offer", "text": "30% off all citrus flavours\nuntil Sunday", "x": 520, "y": 1150, "width": 470, "font": "Poppins-Regular", "size": 30, "color": "#FFFFFF", "align": "right", "lineHeight": 1.3, "group": "CTA" }
  ]
}
```
